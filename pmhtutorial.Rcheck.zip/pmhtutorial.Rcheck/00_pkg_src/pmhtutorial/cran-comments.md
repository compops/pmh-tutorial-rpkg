## Test environments
* Ubuntu 17.04, R 3.4.1
* Windows 10, R 3.4.1

## R CMD check results
There were no NOTEs or ERRORs.

There was 1 WARNING:
* LaTeX errors when creating PDF version. This typically indicates Rd problems.
  However, no error was visible in *Rdlatex.log*.

## Downstream dependencies
There are currently no downstream dependencies for this package.

