pkgname <- "pmhtutorial"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('pmhtutorial')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("example1_lgss")
### * example1_lgss

flush(stderr()); flush(stdout())

### Name: example1_lgss
### Title: State estimation in a linear Gaussian state space model
### Aliases: example1_lgss
### Keywords: misc

### ** Examples

example1_lgss()



cleanEx()
nameEx("example2_lgss")
### * example2_lgss

flush(stderr()); flush(stdout())

### Name: example2_lgss
### Title: Parameter estimation in a linear Gaussian state space model
### Aliases: example2_lgss
### Keywords: misc

### ** Examples

# Change to noIterations=2500, noBurnInIterations=500 for better results
# but longer run times
example2_lgss(noBurnInIterations=50, noIterations=200)



cleanEx()
nameEx("example3_sv")
### * example3_sv

flush(stderr()); flush(stdout())

### Name: example3_sv
### Title: Parameter estimation in a simple stochastic volatility model
### Aliases: example3_sv
### Keywords: misc

### ** Examples

# Change to noIterations=2500, noBurnInIterations=500 for better results
# but longer run times
example3_sv(noBurnInIterations=50, noIterations=200)



cleanEx()
nameEx("example4_sv")
### * example4_sv

flush(stderr()); flush(stdout())

### Name: example4_sv
### Title: Parameter estimation in a simple stochastic volatility model
### Aliases: example4_sv
### Keywords: misc

### ** Examples

# Change to noIterations=2500, noBurnInIterations=500 for better results
# but longer run times
example4_sv(noBurnInIterations=50, noIterations=200)



cleanEx()
nameEx("example5_sv")
### * example5_sv

flush(stderr()); flush(stdout())

### Name: example5_sv
### Title: Parameter estimation in a simple stochastic volatility model
### Aliases: example5_sv
### Keywords: misc

### ** Examples

# Change to noIterations=2500, noBurnInIterations=500 for better results
# but longer run times
example5_sv(noBurnInIterations=50, noIterations=200)



cleanEx()
nameEx("kalmanFilter")
### * kalmanFilter

flush(stderr()); flush(stdout())

### Name: kalmanFilter
### Title: Kalman filter for state estimate in a linear Gaussian state
###   space model
### Aliases: kalmanFilter
### Keywords: ts

### ** Examples

# Generates 500 observations from a linear state space model with
# (phi, sigma_e, sigma_v) = (0.5, 1.0, 0.1) and zero initial state.
theta <- c(0.5, 1.0, 0.1)
d <- generateData(theta, noObservations=500, initialState=0.0) 

# Estimate the filtered state using Kalman filter
kfOutput <- kalmanFilter(d$y, theta, 
                         initialState=0.0, initialStateCovariance=0.01)

# Plot the estimate and the true state
par(mfrow=c(3, 1))
plot(d$x, type="l", xlab="time", ylab="true state", bty="n", 
  col="#1B9E77")
plot(kfOutput$xHatFiltered, type="l", xlab="time", 
  ylab="Kalman filter estimate", bty="n", col="#D95F02")
plot(d$x-kfOutput$xHatFiltered, type="l", xlab="time", 
  ylab="difference", bty="n", col="#7570B3")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("particleFilter")
### * particleFilter

flush(stderr()); flush(stdout())

### Name: particleFilter
### Title: Fully-adapted particle filter for state estimate in a linear
###   Gaussian state space model
### Aliases: particleFilter
### Keywords: ts

### ** Examples

# Generates 500 observations from a linear state space model with
# (phi, sigma_e, sigma_v) = (0.5, 1.0, 0.1) and zero initial state.
theta <- c(0.5, 1.0, 0.1)
d <- generateData(theta, noObservations=100, initialState=0.0) 

# Estimate the filtered state using a Particle filter
pfOutput <- particleFilter(d$y, theta, noParticles = 50, 
  initialState=0.0)

# Plot the estimate and the true state
par(mfrow=c(3, 1))
plot(d$x[1:100], type="l", xlab="time", ylab="true state", bty="n", 
  col="#1B9E77")
plot(pfOutput$xHatFiltered, type="l", xlab="time", 
  ylab="paticle filter estimate", bty="n", col="#D95F02")
plot(d$x[1:100]-pfOutput$xHatFiltered, type="l", xlab="time", 
  ylab="difference", bty="n", col="#7570B3")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("particleFilterSVmodel")
### * particleFilterSVmodel

flush(stderr()); flush(stdout())

### Name: particleFilterSVmodel
### Title: Bootstrap particle filter for state estimate in a simple
###   stochastic volatility model
### Aliases: particleFilterSVmodel
### Keywords: ts

### ** Examples

# Get the data from Quandl
library("Quandl")
d <- Quandl("NASDAQOMX/OMXS30", start_date="2012-01-02", 
            end_date="2014-01-02", type="zoo")
y <- as.numeric(100 * diff(log(d$"Index Value")))

# Estimate the filtered state using a particle filter
theta <- c(-0.10, 0.97, 0.15)
pfOutput <- particleFilterSVmodel(y, theta, noParticles=500)

# Plot the estimate and the true state
par(mfrow=c(2, 1))
plot(y, type="l", xlab="time", ylab="log-returns", bty="n", 
  col="#1B9E77")
plot(pfOutput$xHatFiltered, type="l", xlab="time", 
  ylab="estimate of log-volatility", bty="n", col="#D95F02")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("particleMetropolisHastings")
### * particleMetropolisHastings

flush(stderr()); flush(stdout())

### Name: particleMetropolisHastings
### Title: Particle Metropolis-Hastings algorithm for a linear Gaussian
###   state space model
### Aliases: particleMetropolisHastings
### Keywords: ts

### ** Examples

# Change to 2500 for better results
noIterations <- 200

# Generates 100 observations from a linear state space model with
# (phi, sigma_e, sigma_v) = (0.5, 1.0, 0.1) and zero initial state.
theta <- c(0.5, 1.0, 0.1)
d <- generateData(theta, noObservations=100, initialState=0.0) 

# Estimate the marginal posterior for phi
pmhOutput <- particleMetropolisHastings(d$y,
  initialPhi=0.1, sigmav=1.0, sigmae=0.1, noParticles=50, 
  initialState=0.0, noIterations=noIterations, stepSize=0.10)

# Plot the estimate
nbins <- floor(sqrt(noIterations))
par(mfrow=c(1, 1))
hist(pmhOutput, breaks=nbins, main="", xlab=expression(phi), 
  ylab="marginal posterior", freq=FALSE, col="#7570B3")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("particleMetropolisHastingsSVmodel")
### * particleMetropolisHastingsSVmodel

flush(stderr()); flush(stdout())

### Name: particleMetropolisHastingsSVmodel
### Title: Particle Metropolis-Hastings algorithm for a stochastic
###   volatility model model
### Aliases: particleMetropolisHastingsSVmodel
### Keywords: ts

### ** Examples

# Change to 2500 for better results
noIterations <- 200

# Get the data from Quandl
library("Quandl")
d <- Quandl("NASDAQOMX/OMXS30", start_date="2012-01-02", 
            end_date="2014-01-02", type="zoo")
y <- as.numeric(100 * diff(log(d$"Index Value")))

# Estimate the marginal posterior for phi
pmhOutput <- particleMetropolisHastingsSVmodel(y, 
  initialTheta = c(0, 0.9, 0.2), 
  noParticles=500, 
  noIterations=noIterations, 
  stepSize=diag(c(0.05, 0.0002, 0.002)))

# Plot the estimate
nbins <- floor(sqrt(noIterations))
par(mfrow=c(3, 1))
hist(pmhOutput$theta[,1], breaks=nbins, main="", xlab=expression(mu), 
  ylab="marginal posterior", freq=FALSE, col="#7570B3")
hist(pmhOutput$theta[,2], breaks=nbins, main="", xlab=expression(phi), 
  ylab="marginal posterior", freq=FALSE, col="#E7298A")
hist(pmhOutput$theta[,3], breaks=nbins, main="", 
  xlab=expression(sigma[v]), ylab="marginal posterior", 
  freq=FALSE, col="#66A61E")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("particleMetropolisHastingsSVmodelReparameterised")
### * particleMetropolisHastingsSVmodelReparameterised

flush(stderr()); flush(stdout())

### Name: particleMetropolisHastingsSVmodelReparameterised
### Title: Particle Metropolis-Hastings algorithm for a stochastic
###   volatility model model
### Aliases: particleMetropolisHastingsSVmodelReparameterised
### Keywords: ts

### ** Examples

# Change to 2500 for better results
noIterations <- 200

# Get the data from Quandl
library("Quandl")
d <- Quandl("NASDAQOMX/OMXS30", start_date="2012-01-02", 
            end_date="2014-01-02", type="zoo")
y <- as.numeric(100 * diff(log(d$"Index Value")))

# Estimate the marginal posterior for phi
pmhOutput <- particleMetropolisHastingsSVmodelReparameterised(
  y, initialTheta = c(0, 0.9, 0.2), noParticles=500, 
  noIterations=noIterations, stepSize=diag(c(0.05, 0.0002, 0.002)))

# Plot the estimate
nbins <- floor(sqrt(noIterations))
par(mfrow=c(3, 1))
hist(pmhOutput$theta[,1], breaks=nbins, main="", xlab=expression(mu), 
  ylab="marginal posterior", freq=FALSE, col="#7570B3")
hist(pmhOutput$theta[,2], breaks=nbins, main="", xlab=expression(phi), 
  ylab="marginal posterior", freq=FALSE, col="#E7298A")
hist(pmhOutput$theta[,3], breaks=nbins, main="", 
  xlab=expression(sigma[v]), ylab="marginal posterior", 
  freq=FALSE, col="#66A61E")



graphics::par(get("par.postscript", pos = 'CheckExEnv'))
### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
