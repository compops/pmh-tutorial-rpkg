# pmhtutorial 1.1
* Refactorised code and changed names of
  inputs and outputs to better reflect
  their meaning.
* Added a new function for generating 
  plots similar to the reference paper
  to this software package.
* Various minor bug fixes.

# pmhtutorial 1.0.1
* Bug fixes related the the plots.
* Added the Markov chain trace to the variables
  retured from example3_sv, example4_sv and
  example5_sv.

# pmhtutorial 1.0.0
* Initial release.
